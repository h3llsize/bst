export interface City {
  name: string
  domain: string
}
