export const TOKEN_KEY = '__TOKEN_KEY__'
export const CART_KEY = '__CART_KEY__'
