Install `pnpm` - https://pnpm.io/installation (`npm install -g pnpm`)

# Development

```
pnpm run dev
```

# Production

```
pnpm run build

node --env-file .env .output/server/index.mjs
```
