export default defineAppConfig({
  name: 'БСТ',
})
