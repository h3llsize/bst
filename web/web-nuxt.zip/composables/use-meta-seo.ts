import { useHead } from 'unhead'
import { MetaPostDTO, Services } from '#/utils/api'
import type { MetaTag } from '#/types/common'

export async function useLoadMeta(params?: Partial<MetaPostDTO>) {
  let meta = {} as MetaTag

  try {
    const metaDto = new MetaPostDTO()

    metaDto.type = params?.type ?? ''
    metaDto.slug = params?.slug ?? ''
    metaDto.city = params?.city ?? useCookie('subdomain').value ?? 'moscow'

    meta = await Services.getMeta(metaDto)
  }
  catch (e) {
    // ? я не знаю чего тут происходит :)
    meta.openGraph = {
      title: 'Категория металлопроката',
      description: 'Категория каталога металлопроката',
      image: '',
      locality: 'Пермь',
      locale: 'ru_RU',
      siteName: 'БСТ',
      type: 'website',
    }

    meta.otherDTO = {
      description: 'Категория каталога металлопроката',
      keywords: 'металлопрокат, категория католога, металл, бст',
      title: 'Категория металлопроката',
    }
  }

  const applySeoMeta = () => {
    useHead({
      title: meta?.otherDTO?.title,
      meta: [
        {
          name: 'description',
          content: meta?.otherDTO?.description,
        },
        {
          name: 'ogTitle',
          content: meta?.openGraph?.title,
        },
        {
          name: 'ogDescription',
          content: meta?.openGraph?.description,
        },
        {
          name: 'ogImage',
          content: meta?.openGraph?.image,
        },
        {
          name: 'ogSiteName',
          content: meta?.openGraph?.siteName,
        },
        {
          name: 'ogLocale',
          content: meta?.openGraph?.locale,
        },
        {
          name: 'ogLocaleAlternate',
          content: meta?.openGraph?.locality,
        },
        {
          name: 'twitterTitle',
          content: meta?.otherDTO?.title,
        },
        {
          name: 'ogUrl',
          content: window?.location?.href,
        },
        {
          name: 'twitterDescription',
          content: meta?.otherDTO?.description,
        },
        {
          name: 'twitterImage',
          content: meta?.openGraph?.image,
        },
        {
          name: 'twitterCard',
          content: 'app',
        },
      ],
    })
  }

  return { meta, applySeoMeta, seoMeta: {} }
}
